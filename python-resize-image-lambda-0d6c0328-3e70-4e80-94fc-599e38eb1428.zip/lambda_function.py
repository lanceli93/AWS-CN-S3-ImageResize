import boto3
import re
import os
import json
from io import BytesIO
from PIL import Image
import logging
import urllib.parse

# 配置日志
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# 初始化S3客户端
s3 = boto3.client('s3')

def lambda_handler(event, context):
    """
    S3 Object Lambda函数，用于动态调整图像大小
    根据请求的文件名(如sunset_600x400.jpg)调整原始图像(如sunset.jpg)的大小
    """
    # logger.info(f"Received event: {json.dumps(event)}")
    
    # 从事件中获取请求上下文
    object_context = event["getObjectContext"]
    request_route = object_context["outputRoute"]
    request_token = object_context["outputToken"]
    
    # 从用户请求中获取对象键
    # 只取URL路径的最后部分作为对象键
    url_path = event["userRequest"]["url"]
    object_key = os.path.basename(url_path.rstrip('/'))
    logger.info(f"Object key requested: {object_key}")
    
    # 从配置中获取支持的访问点ARN
    supporting_access_point_arn = event["configuration"]["supportingAccessPointArn"]
    logger.info(f"Supporting access point ARN: {supporting_access_point_arn}")
    
    try:
        # 解析文件名中的尺寸信息
        # 例如: sunset_600x400.jpg -> 宽度=600, 高度=400, 原始文件名=sunset.jpg
        match = re.match(r'(.+)_(\d+)x(\d+)(\.\w+)$', object_key)
        
        if not match:
            # 如果文件名不符合格式，返回错误
            error_message = f"Invalid filename format: {object_key}. Expected format: filename_widthxheight.extension"
            logger.error(error_message)
            s3.write_get_object_response(
                StatusCode=400,
                ErrorCode='InvalidRequest',
                ErrorMessage=error_message,
                RequestRoute=request_route,
                RequestToken=request_token
            )
            return {'status_code': 400}
        
        # 解析文件名
        base_name = match.group(1)
        width = int(match.group(2))
        height = int(match.group(3))
        extension = match.group(4)
        original_key = f"{base_name}{extension}"
        
        logger.info(f"Parsed dimensions: {width}x{height}")
        logger.info(f"Original image key: {original_key}")
        
        # 直接使用支持的访问点ARN获取原始图像
        try:
            # 创建一个新的S3客户端，配置为使用访问点
            s3_ap = boto3.client('s3', 
                                region_name=supporting_access_point_arn.split(':')[3],
                                config=boto3.session.Config(s3={'addressing_style': 'virtual'}))
            
            response = s3_ap.get_object(
                Bucket=supporting_access_point_arn,
                Key=original_key
            )
            original_image_data = response['Body'].read()
            logger.info(f"Successfully retrieved original image using supporting access point ARN")
        except Exception as e:
            logger.error(f"Error retrieving original image: {str(e)}")
            s3.write_get_object_response(
                StatusCode=500,
                ErrorCode='InternalServerError',
                ErrorMessage=f"Failed to retrieve original image: {str(e)}",
                RequestRoute=request_route,
                RequestToken=request_token
            )
            return {'status_code': 500}
        
        # 使用PIL处理图像
        try:
            with Image.open(BytesIO(original_image_data)) as img:
                # 保持纵横比调整大小
                img.thumbnail((width, height), Image.LANCZOS)
                
                # 将调整后的图像保存到内存中
                buffer = BytesIO()
                img_format = img.format if img.format else 'JPEG'
                img.save(buffer, format=img_format)
                resized_image_data = buffer.getvalue()
                
                # 返回调整大小后的图像
                s3.write_get_object_response(
                    Body=resized_image_data,
                    RequestRoute=request_route,
                    RequestToken=request_token,
                    ContentType=f"image/{img_format.lower()}"
                )
                
                logger.info(f"Successfully resized image to {img.width}x{img.height}")
                return {'status_code': 200}
        except Exception as e:
            logger.error(f"Error processing image: {str(e)}")
            s3.write_get_object_response(
                StatusCode=500,
                ErrorCode='InternalServerError',
                ErrorMessage=f"Failed to process image: {str(e)}",
                RequestRoute=request_route,
                RequestToken=request_token
            )
            return {'status_code': 500}
            
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        # 发生错误时，返回错误响应
        s3.write_get_object_response(
            StatusCode=500,
            ErrorCode='InternalServerError',
            ErrorMessage=str(e),
            RequestRoute=request_route,
            RequestToken=request_token
        )
        return {'status_code': 500}
